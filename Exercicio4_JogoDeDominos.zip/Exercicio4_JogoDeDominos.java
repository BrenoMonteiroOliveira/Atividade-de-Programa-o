import java.util.Scanner;

public class Exercicio4_JogoDeDominos {

    public static void main(String[] args) {

        try (Scanner entrada = new Scanner(System.in)) {
            int N = entrada.nextInt();

            int resultado = (N + 1) * (N + 2) / 2;

            System.out.println(resultado);
        }
    }
}