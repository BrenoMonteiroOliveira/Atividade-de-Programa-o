import java.util.Scanner;

public class Exercicio3_calculo_rapido {

    public static void main(String[] args) {

        try (Scanner entrada = new Scanner(System.in)) {
            int S = entrada.nextInt();
            int A = entrada.nextInt();
            int B = entrada.nextInt();

            int contador = 0;

            for (int numero = A; numero <= B; numero++) {

                int temp = numero;
                int soma = 0;

                while (temp > 0) {

                    soma += temp % 10;
                    temp /= 10;
                }

                if (soma == S) {
                    contador++;
                }
            }

            System.out.println(contador);
        }
    }
}