
import java.util.Scanner;

public class Exercicio2_TorneioDeTenis {

    public static void main(String[] args) {

        try (Scanner entrada = new Scanner(System.in)) {
            int vitorias = 0;

            for (int i = 0; i < 6; i++) {

                String resultado = entrada.next();

                if (resultado.equals("V")) {
                    vitorias++;
                }
            }

            if (vitorias >= 5) {
                System.out.println(1);

            } else if (vitorias >= 3) {
                System.out.println(2);

            } else if (vitorias >= 1) {
                System.out.println(3);

            } else {
                System.out.println(-1);
            }
        }
    }
}