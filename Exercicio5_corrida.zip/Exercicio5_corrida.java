import java.util.Scanner;

public class Exercicio5_corrida {

    public static void main(String[] args) {

        try (Scanner entrada = new Scanner(System.in)) {

        int n1 = entrada.nextInt();
        int d1 = entrada.nextInt();
        int v1 = entrada.nextInt();

        int n2 = entrada.nextInt();
        int d2 = entrada.nextInt();
        int v2 = entrada.nextInt();

        double tempo1 = d1 / (double) v1;
        double tempo2 = d2 / (double) v2;

        if (tempo1 < tempo2) {
            System.out.println(n1);
        } else {
            System.out.println(n2);
        }

        }
    }
}